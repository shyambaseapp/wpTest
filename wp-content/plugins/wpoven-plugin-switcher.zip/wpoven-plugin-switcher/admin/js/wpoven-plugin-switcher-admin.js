(function ($) {
  "use strict";

  /**
   * All of the code for your admin-facing JavaScript source
   * should reside in this file.
   *
   * Note: It has been assumed you will write jQuery code here, so the
   * $ function reference has been prepared for usage within the scope
   * of this function.
   *
   * This enables you to define handlers, for when the DOM is ready:
   *
   * $(function() {
   *
   * });
   *
   * When the window is loaded:
   *
   * $( window ).load(function() {
   *
   * });
   *
   * ...and/or other possibilities.
   *
   * Ideally, it is not considered best practise to attach more than a
   * single DOM-ready or window-load handler for a particular page.
   * Although scripts in the WordPress core, Plugins and Themes may be
   * practising this, we should strive to set a better example in our own work.
   */

  $(function () {
    $(".wps-rule-name input").change(function (event) {
      var oldHTML = $(this)
        .closest(".csf-accordion-item")
        .find(".csf-accordion-title")
        .html();
      var oldTXT = $(this)
        .closest(".csf-accordion-item")
        .find(".csf-accordion-title")
        .text();

      var newHTML = oldHTML.replace(oldTXT, $(this).val());

      $(this)
        .closest(".csf-accordion-item")
        .find(".csf-accordion-title")
        .html(newHTML);
      //.replace( $(this).text(), 'Some value');
      //html( $(this).val() )
    });

    $('input[data-depend-id="add-rule-button"]')
      .parent()
      .click(function (event) {
        // Prompt the user to enter some text
        var userInput = prompt("Please enter rule name:");

        if (userInput === null) {
          return; //break out of the function early
        }

        // Check if the user entered something
        if (userInput) {
          // Display the entered text in the 'displayText' div

          event.preventDefault();
          event.stopImmediatePropagation();

          var form = document.createElement("form");
          form.setAttribute("method", "post");

          var createField = document.createElement("input");
          createField.setAttribute("type", "text");
          createField.setAttribute("name", "rule_name");
          createField.setAttribute("value", userInput);

          form.appendChild(createField);
          document.body.appendChild(form);

          form.submit();

          return false;
        } else {
          // Handle the case where the user pressed cancel or entered nothing
          alert("No text was entered.");
        }
      });
  });

  //alert($('.csf-copyright').text())
})(jQuery);
