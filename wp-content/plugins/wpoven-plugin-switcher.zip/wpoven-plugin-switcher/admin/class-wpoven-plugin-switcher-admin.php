<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       https://www.wpoven.com/plugins/
 * @since      1.0.0
 *
 * @package    Wpoven_Plugin_Switcher
 * @subpackage Wpoven_Plugin_Switcher/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Wpoven_Plugin_Switcher
 * @subpackage Wpoven_Plugin_Switcher/admin
 * @author     Vikas Patial <VIKAS@BASEAPP.COM>
 */
class Wpoven_Plugin_Switcher_Admin
{

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;
	private $_wpbase_plugin_switcher;
	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct($plugin_name, $version)
	{

		$this->plugin_name = $plugin_name;
		$this->version = $version;

		if (!class_exists('CSF')) {
			require_once plugin_dir_path(dirname(__FILE__)) . 'includes/codestar/codestar-framework.php';
		}
		if (!function_exists('is_plugin_active')) {
			include_once(ABSPATH . 'wp-admin/includes/plugin.php');
		}
	}

	/**
	 * Register the stylesheets for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles()
	{

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Wpoven_Plugin_Switcher_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Wpoven_Plugin_Switcher_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style($this->plugin_name, plugin_dir_url(__FILE__) . 'css/wpoven-plugin-switcher-admin.css', array(), $this->version, 'all');
	}

	/**
	 * Register the JavaScript for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts()
	{

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Wpoven_Plugin_Switcher_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Wpoven_Plugin_Switcher_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_script($this->plugin_name, plugin_dir_url(__FILE__) . 'js/wpoven-plugin-switcher-admin.js', array('jquery'), $this->version, false);
	}

	function getRandomString($n)
	{
		$characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
		$randomString = '';

		for ($i = 0; $i < $n; $i++) {
			$index = rand(0, strlen($characters) - 1);
			$randomString .= $characters[$index];
		}

		return $randomString;
	}

	function wpoven_plugin_switcher_optimized_group_of_plugins($options)
	{
		$create = isset($_POST['rule_name']) ? $_POST['rule_name'] : false;

		if ($create) {
			$ruleName = sanitize_text_field($_POST['rule_name']);
			$uid = $this->getRandomString(4);

			if (!isset($options['wps_settings']) || !is_array($options['wps_settings'])) {
				$options['wps_settings'] = array();
			}

			if (!isset($options['wps_settings']['wps_rules'])) {
				$options['wps_settings']['wps_rules'] = array();
			}

			$options['wps_settings']['wps_rules']['v' . $uid . '_name'] =  $ruleName;
			update_option('wpoven-plugin-switcher', $options);
		}

		$delete = isset($_GET['delete']) ? $_GET['delete'] : false;

		if ($delete) {
			$uid = sanitize_text_field($delete);
			foreach ($options['wps_settings']['wps_rules'] as $key => $rule) {
				if (isset($options['wps_settings']['wps_rules'][$key]) && strstr($key, $uid)) {
					unset($options['wps_settings']['wps_rules'][$key]);
					update_option(WPOVEN_PLUGIN_SWITCHER_SLUG, $options);

					$this->wpoven_plugin_options_process($options);

					header('Location: ' . admin_url('/admin.php?page=wpoven-plugin-switcher'));
					die();
				}
			}
		}

		$active_plugins = get_option('active_plugins');

		foreach ($active_plugins as $key => $plugin) {
			$parts = explode("/", $plugin);
			$option_value = $parts[0];
			$plugin_options[$plugin] = $option_value;
		}

		$accordions = array();

		if (isset($options['wps_settings']['wps_rules'])) {

			$uids = array();

			foreach ($options['wps_settings']['wps_rules'] as $var => $val) {
				if (strstr($var, '_name')) {
					list($uid, $dummy) = explode('_', $var);
					$uids[] = $uid;
				}
			}

			foreach ($uids as $uid) {

				$rules = $options['wps_settings']['wps_rules'];

				$fields = array();

				$ruleName   = isset($rules[$uid . '_name']) ? $rules[$uid . '_name'] : '';
				$ruleStatus = isset($rules[$uid . '_status']) ? $rules[$uid . '_status'] : '';

				//global $wp;
				$current_url = add_query_arg($_SERVER['QUERY_STRING'], '', admin_url('admin.php'));

				$delteURL = $current_url . '&delete=' . $uid;

				$nameField = array(
					'id'    => $uid . '_name',
					'type'  => 'text',
					'title' => 'Name',
					'class' => 'wps-rule-name',
					'after' => '<a href="' . $delteURL . '" style="cursor: pointer;" onclick="return confirm(\'Are you sure you want to delete this rule ?\');" >Delete Rule</a>',
					'default' =>  $ruleName,
				);

				$statusField = array(
					'id'    => $uid . '_status',
					'type'  => 'switcher',
					'title' => 'Status',
				);

				$typeField   = array(
					'id'          => $uid . '_type',
					'type'        => 'select',
					'title'       => 'Rule Type:',
					'options'     => array(
						'page'  => 'Page',
						'post'  => 'Post',
						'url'  => 'URL',
					),
					'default'     => 'page',
				);


				$pageField  =	array(
					'id'          => $uid . "_pages",
					'type'        => 'select',
					'title'       => 'Select Pages',
					'placeholder' => 'Select an option',
					'dependency' => array($uid . '_type', 'any', 'page'),
					'chosen'      => true,
					'multiple'    => true,
					'width'       => 'auto',
					'ajax'        => true,
					'options'     => 'pages',
				);

				$postField =	array(
					'id'          => $uid . "_posts",
					'type'        => 'select',
					'title'       => 'Select Posts',
					'dependency' => array($uid . '_type', 'any', 'post'),
					'placeholder' => 'Select an option',
					'chosen'      => true,
					'multiple'    => true,
					'min_length'  => 3,
					'options'     => 'posts',
					'ajax'        => true,
				);

				$urlField =	array(
					'id'          => $uid . "_url",
					'type'        => 'text',
					'title'       => 'URL Match',
					'dependency' => array($uid . '_type', 'any', 'url'),
					'placeholder' => 'E.g: /contact-us',
					'type'  => 'text',
				);

				$pluginField  = array(
					'id'          => $uid . "_plugins",
					'type'        => 'select',
					'title'       => 'Select Plugins',
					'placeholder' => 'Select an option',
					'chosen'      => true,
					'multiple'    => true,
					'min_length'  => 3,
					'desc' => 'Select the list of plugin',
					'options'     => $plugin_options,
				);

				$pluginStatusField  = array(
					'id'    => $uid . '_plugin_status',
					'type'  => 'switcher',
					'title' => 'Plugin Status',
					'text_on'  => 'Active',
					'text_off' => 'Deactivate',
					'desc' => 'This rule should activate the plugin or deactivate active plugins',
					'text_width' => 100,
				);

				$fields[] = $nameField;
				$fields[] = $statusField;
				$fields[] = $typeField;
				$fields[] = $pageField;
				$fields[] = $postField;
				$fields[] = $urlField;
				$fields[] = $pluginField;
				$fields[] = $pluginStatusField;

				$accordion = array(
					'title'     => $ruleName,
					'type'      => 'accordion',
					'class'     => 'apply_color',
					'after'         => 'aft',
					'fields'    => $fields
				);

				if ($ruleStatus) {
					$accordion['icon'] = 'fa fa-check';
				}

				$accordions[] = $accordion;
			}
		}

		$result = array(
			'id'            => 'wps_rules',
			'type'          => 'accordion',
			'title'         => 'Rule Lists',
			'accordions'    =>  $accordions,
		);

		return $result;
	}

	/**
	 * Add a admin menu.
	 */
	function wpoven_plugin_switcher_menu()
	{
		add_menu_page('WPOven Plugin Switcher', 'WPOven Plugin Switcher', 'manage_options', 'admin.php?page=' . WPOVEN_PLUGIN_SWITCHER_SLUG);
	}

	/**
	 * Set wpoven plugin switcher admin page.
	 */
	function setup_gui()
	{
		$options = get_option(WPOVEN_PLUGIN_SWITCHER_SLUG);

		CSF::createOptions(WPOVEN_PLUGIN_SWITCHER_SLUG, array(
			'menu_title' => WPOVEN_PLUGIN_SWITCHER,
			'menu_slug'  => WPOVEN_PLUGIN_SWITCHER_SLUG,
			'framework_title' => WPOVEN_PLUGIN_SWITCHER,
			'footer_credit' => ' ',
			'footer_text' => 'WPOven Plugin Switcher',
			'show_bar_menu' => true,
			'menu_hidden' => true,
			'show_reset_section' => false,
			'show_reset_all' => false
		));

		$addRule = array(
			'id'         => 'add-rule-button',
			'type'       => 'button_set',
			'title'      => '&nbsp;',
			'options'    => array(
				'enabled'  => 'Add Rule',
			),
			'default'    => 'enabled'
		);

		$debug = array('type' => 'content', 'content' => print_r($options, true));

		CSF::createSection(WPOVEN_PLUGIN_SWITCHER_SLUG, array(
			'fields' => array(
				array(
					'id'            => 'wps_settings',
					'type'          => 'tabbed',
					'tabs'          => array(
						array(
							'title'     => 'Activation & Deactivation Rules',
							'icon'      => 'fa fa-gear',
							'fields'    => array(
								$this->wpoven_plugin_switcher_optimized_group_of_plugins($options),
								$addRule,
								//$debug
							)
						),
					)
				),
			)
		));
	}

	/**
	 *  Adding MU-Plugin file.
	 */
	function add_mu_plugin($enable)
	{
		$wpoven_muplugin_source_path = WPOVEN_PLUGIN_SWITCHER_ROOT_DIR . '/mu-plugin/class-wpoven-plugin-switcher-mu-plugin.php';
		$mu_plugins_dir_path = WP_CONTENT_DIR . '/' . 'mu-plugins';
		$mu_plugin_file_path = $mu_plugins_dir_path . '/class-wpoven-plugin-switcher-mu-plugin.php';
		if (!is_dir($mu_plugins_dir_path)) {
			mkdir($mu_plugins_dir_path, 0755, true);
		}
		if ($enable) {
			if (is_dir($mu_plugins_dir_path)) {
				copy($wpoven_muplugin_source_path, $mu_plugin_file_path);
			}
		} elseif (file_exists($mu_plugin_file_path)) {
			unlink($mu_plugin_file_path);
		}
	}

	function wpoven_plugin_options_process($options)
	{
		//var_dump($options);
		if (isset($options['wps_settings']['wps_rules']) && is_array($options['wps_settings']['wps_rules'])) {
			$rules = $options['wps_settings']['wps_rules'];
			$values = array('name', 'status', 'pages', 'posts', 'plugin_status', 'plugins', 'type', 'url'); // custom removed
			$uids = array();

			foreach ($options['wps_settings']['wps_rules'] as $var => $val) {
				if (strstr($var, '_name')) {
					list($uid, $dummy) = explode('_', $var);
					$uids[] = $uid;
				}
			}

			$rule_status = array();
			$processed_rules = array();
			foreach ($uids as $uid) {
				$processed_rule = array();
				foreach ($values as $value) {
					if (isset($rules[$uid . '_' . $value])) {
						$processed_rule[$value] = $rules[$uid . '_' . $value];
						if ($value == 'status') {
							$rule_status[] = $rules[$uid . '_status'];
						}
					}
				}
				$processed_rules[] = $processed_rule;
			}

			$enable = false;
			if (in_array(1, $rule_status)) {
				$enable = true;
			}
			$this->add_mu_plugin($enable);

			update_option(WPOVEN_PLUGIN_SWITCHER_SLUG . '-rules', $processed_rules);
		}
	}

	/**
	 * Hook to add the admin menu.
	 */
	public function admin_main(Wpoven_Plugin_Switcher $wpoven_plugin_switcher)
	{
		$this->_wpoven_plugin_switcher = $wpoven_plugin_switcher;
		add_action('admin_menu', array($this, 'wpoven_plugin_switcher_menu'));
		add_action('csf_' . WPOVEN_PLUGIN_SWITCHER_SLUG . '_saved', array($this, 'wpoven_plugin_options_process'));
		$this->setup_gui();
	}
}
