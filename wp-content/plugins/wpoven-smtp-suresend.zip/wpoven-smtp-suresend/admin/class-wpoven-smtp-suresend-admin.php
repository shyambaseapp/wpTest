<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;
use WPOVEN\LIST\TABLE\WPoven_List_Table;

use function PHPSTORM_META\type;

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       https://www.wpoven.com/plugins/
 * @since      1.0.0
 *
 * @package    Wpoven_Smtp_Suresend
 * @subpackage Wpoven_Smtp_Suresend/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Wpoven_Smtp_Suresend
 * @subpackage Wpoven_Smtp_Suresend/admin
 * @author     Shyam Sundar Maury <shyam.baseapp@gmail.com>
 */
class Wpoven_Smtp_Suresend_Admin
{

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;
	private $_wpoven_smtp_suresend;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct($plugin_name, $version)
	{
		$this->plugin_name = $plugin_name;
		$this->version = $version;
		if (!class_exists('CSF')) {
			require_once plugin_dir_path(dirname(__FILE__)) . 'includes/codestar/codestar-framework.php';
		}
		if (!function_exists('is_plugin_active')) {
			include_once(ABSPATH . 'wp-admin/includes/plugin.php');
		}
		if (!class_exists('PHPMailer')) {
			require_once ABSPATH . WPINC . '/PHPMailer/PHPMailer.php';
			require_once ABSPATH . WPINC . '/PHPMailer/SMTP.php';
			require_once ABSPATH . WPINC . '/PHPMailer/Exception.php';
		}
		// if (!class_exists('PHPMailer')) {
		// 	require_once  plugin_dir_path(dirname(__FILE__)) . 'vendor/autoload.php';
		// }

		if (!class_exists('WPoven_List_Table')) {
			require_once plugin_dir_path(dirname(__FILE__)) . '/includes/class-wpove-smtp-suresend-list-table.php';
		}
		require_once ABSPATH . WPINC . '/pluggable.php';
		add_filter('wp_mail', [$this, 'log_email']);
	}

	/**
	 * Register the stylesheets for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles()
	{

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Wpoven_Smtp_Suresend_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Wpoven_Smtp_Suresend_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style($this->plugin_name, plugin_dir_url(__FILE__) . 'css/wpoven-smtp-suresend-admin.css', array(), $this->version, 'all');
	}

	/**
	 * Register the JavaScript for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts()
	{

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Wpoven_Smtp_Suresend_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Wpoven_Smtp_Suresend_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_script($this->plugin_name, plugin_dir_url(__FILE__) . 'js/wpoven-smtp-suresend-admin.js', array('jquery'), $this->version, false);
	}

	/**
	 * Add a admin menu.
	 */
	function wpoven_smtp_suresend_menu()
	{
		$to = null;
		$subject = null;
		$message = null;
		$headers = null;
		$attachments = array();
		wp_mail($to, $subject, $message, $headers, $attachments);
		add_menu_page('WPOven SMTP Suresend', 'WPOven SMTP Suresend', 'manage_options', 'admin.php?page=' . WPOVEN_SMTP_SURESEND_SLUG);
		add_submenu_page('admin.php?page=' . WPOVEN_SMTP_SURESEND_SLUG, 'SMTP Logs', 'SMTP Logs', 'manage_options', WPOVEN_SMTP_SURESEND_SLUG . '-smtp-logs', array($this, 'smtp_logs'));
	}

	/**
	 * Call function when wp_mail() trigger.
	 */
	function log_email($mailArray)
	{
		if ($mailArray['to']) {
			$options = get_option(WPOVEN_SMTP_SURESEND_SLUG);
			$option = $options['wpsmtp_settings'] ?? null;
			$smtp_option = $option['smtp-method-option'];

			$status = 'failed';
			$form_data = array(
				'emailTo' => $mailArray['to'],
				'subject' => $mailArray['subject'],
				'headers' => $mailArray['headers'],
				'message' => $mailArray['message'],
				'text_format' => true,
				'status' => $status
			);

			if ($smtp_option == 'smtp') {
				$mail = $this->wpoven_smtp_check_connection();
				if ($mail) {
					$form_data['status'] = 'success';
					$this->send_mail($mail, $form_data);
				}
			} else {
				$this->wpoven_save_smtp_logs($form_data);
			}
		}
	}

	/**
	 * Check SMTP Server Connection.
	 */
	function wpoven_smtp_check_connection()
	{
		$options = get_option(WPOVEN_SMTP_SURESEND_SLUG);
		$option = $options['wpsmtp_settings'] ?? null;
		$host = $option['host'] ?? null;
		$username = $option['username'] ?? null;
		$password = $option['password'] ?? null;
		$encryption = $option['encryption'] ?? null;
		$port = $option['port'] ?? null;

		$mail = new PHPMailer(true);

		try {
			$mail->isSMTP();
			$mail->Host = $host;
			$mail->SMTPAuth = true;
			$mail->Username = $username;
			$mail->Password = $password;
			$mail->SMTPSecure = $encryption;
			$mail->Port = $port;
			// Enable debugging
			$mail->SMTPDebug = 2; // Set to 2 to see more detailed output
			$mail->Debugoutput = function ($str) {
				static $debug = '';
				$debug .= "$str";
				$str = str_replace(array("CLIENT -> SERVER: ", "SERVER -> CLIENT: "), "", $debug);
				$_SESSION['debug_log'] = $str;
			};
			$mail->SMTPConnect();
			if ($mail) {
				return $mail;
			}
		} catch (Exception $e) {
			return false;
		}
	}

	/**
	 * Send mail if SMTP server connected.
	 */
	function send_mail($mail, $form_data)
	{
		$options = get_option(WPOVEN_SMTP_SURESEND_SLUG);
		$option = $options['wpsmtp_settings'];
		$from = $option['from-email'] ?? null;
		$name = $option['from-name'] ?? null;
		if (!empty($form_data['emailTo']) && !empty($from)) {
			$form_data['status'] = 'failed';
			$form_data['headers'] = $form_data['headers'] . '&nbsp;&nbsp;Replay-to:';
			try {
				if ($mail) {
					$form_data['status'] = 'success';
					$mail->setFrom($from, $name);
					$mail->addAddress($form_data['emailTo']);
					$mail->isHTML($form_data['text_format']);                                  //Set email format to HTML
					$mail->Subject = $form_data['subject'];
					$mail->Body    = $form_data['message'];
					$mail->AltBody = 'This is the body in plain text for non-HTML mail clients';
					$mail->send();
					$this->wpoven_save_smtp_logs($form_data);
					return true;
				}
			} catch (Exception $e) {
				return false;
			}
		}
	}

	/**
	 *Save logs in database.
	 */
	function wpoven_save_smtp_logs($form_data)
	{
		global $wpdb;
		$table_name = $wpdb->prefix . 'wpoven_smtp_suresend_logs';
		if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name) {
			$charset_collate = $wpdb->get_charset_collate();
			$sql = "CREATE TABLE $table_name (
					id INT NOT NULL AUTO_INCREMENT,
					time DATETIME NOT NULL,
					recipient VARCHAR(255) NOT NULL,
					subject VARCHAR(255) NOT NULL,
					headers VARCHAR(255) NOT NULL,
					status VARCHAR(20) NOT NULL,
					message TEXT NOT NULL,
					smtplogs TEXT,
					PRIMARY KEY (id)
    		) $charset_collate;";
			require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
			dbDelta($sql);
		}
		$log = isset($_SESSION['debug_log']) ? $_SESSION['debug_log'] : null;
		$data_to_insert = array(
			'time' => current_time('mysql'),
			'recipient' => sanitize_email($form_data['emailTo']),
			'subject' => sanitize_text_field($form_data['subject']),
			'headers' => sanitize_text_field($form_data['headers']),
			'status' => sanitize_text_field($form_data['status']),
			'message' => $form_data['message'],
			'smtplogs' => sanitize_textarea_field($log),
		);
		$wpdb->insert($table_name, $data_to_insert);
	}

	/**
	 * SMTP Server General Settings.
	 */
	function wpoven_smtp_suresend_general_settings($options)
	{
		$option = $options['wpsmtp_settings'];
		$smtp_option = $option['smtp-method-option'] ?? null;
		$conn = 'Not Connected';
		$statusColor = "red";
		if ($smtp_option == 'smtp') {
			$mail = $this->wpoven_smtp_check_connection();
			if ($mail) {
				$conn = 'Connected';
				$statusColor = "green";
			}
		}

		$fields = array();

		$from_email_address = array(
			'id'      => 'from-email',
			'type'    => 'text',
			'title'   => 'From Email Address',
			'validate' => 'csf_validate_email',
			'placeholder'  => 'example@gmail.com',
			'desc'  => 'Sender address for sending emails.',
		);

		$from_name = array(
			'id'      => 'from-name',
			'type'    => 'text',
			'title'   => 'From Name',
			'desc'  => 'Sender Name.',
		);

		$smtp_method_options = array(
			'id'          => 'smtp-method-option',
			'type'        => 'select',
			'title'       => 'Sending Option',
			'desc'  => 'Select option for test mail',
			'options'     => array(
				'php'  => 'PHP',
				'smtp'  => 'SMTP'
			),
			'default'     => 'php'
		);

		$smtp_host = array(
			'id'      => 'host',
			'type'    => 'text',
			'title'   => 'Host',
			'desc'  => 'SMTP client host.',
			'dependency' => array('smtp-method-option', '==', 'smtp'),
			'placeholder'  => 'smtp.example.io',
			'before' => '<strong name="status" style="color:' . $statusColor . ';">' . $conn . '</strong>',
		);
		$smtp_username = array(
			'id'      => 'username',
			'type'    => 'text',
			'title'   => 'Username',
			'desc'  => 'SMTP client username.',
			'dependency' => array('smtp-method-option', '==', 'smtp'),
		);
		$smtp_password = array(
			'id'      => 'password',
			'type'    => 'text',
			'title'   => 'Password',
			'attributes'  => array(
				'type'      => 'password',
				'maxlength' => 20,
			),
			'desc'  => 'SMTP client password.',
			'dependency' => array('smtp-method-option', '==', 'smtp'),
		);

		$smtp_encryption = array(
			'id'          => 'encryption',
			'type'        => 'select',
			'title'       => 'Type of Encryption',
			'desc'  => 'The encryption which will be used when sending an email (TLS is recommended).',
			'options'     => array(
				'tls'  => 'TLS',
				'ssl'  => 'SSL'
			),
			'default'     => 'tls',
			'dependency' => array('smtp-method-option', '==', 'smtp'),
		);
		$smtp_port = array(
			'id'      => 'port',
			'type'    => 'number',
			'title'   => 'SMTP Port',
			'desc'  => 'For TLS, use port 25, 587; for SSL, use port 465.',
			'dependency' => array('smtp-method-option', '==', 'smtp'),
		);

		$fields[] = $from_email_address;
		$fields[] = $from_name;
		$fields[] = $smtp_method_options;
		$fields[] = $smtp_host;
		$fields[] = $smtp_username;
		$fields[] = $smtp_password;
		$fields[] = $smtp_encryption;
		$fields[] = $smtp_port;

		$result = array(
			'title'     => 'General',
			'icon'      => 'fa fa-gear',
			'fields'    => $fields
		);
		return $result;
	}


	function get_form_data()
	{
		$form_data = array();
		$emailTo = isset($_POST['email_to']) ? $_POST['email_to'] : false;
		$text_format = isset($_POST['text_format']) ? $_POST['text_format'] : false;
		if ($emailTo) {
			$emailTo = sanitize_text_field($_POST['email_to']);
			$subject = 'SMTP Test';
			$message = 'This is a SMTP test mail';

			$form_data = array(
				'emailTo' => $emailTo,
				'subject' => $subject,
				'headers' => 'Content-Type: text/html',
				'message' => $message,
				'text_format' => $text_format
			);
		}

		return $form_data;
	}

	/**
	 * Send SMTP test mail after SMTP server connection established.
	 */
	function wpoven_smtp_suresend_smtp_test_settings($options)
	{
		$fields = array();

		$options = get_option(WPOVEN_SMTP_SURESEND_SLUG);
		$option = $options['wpsmtp_settings'];
		$smtp_option = $option['smtp-method-option'];

		$form_data = $this->get_form_data();

		$notice = array(
			'type'  => 'notice',
			'style'  => '',
			'content'  => '',
		);

		if ($form_data) {
			switch ($smtp_option) {
				case 'php':
					$attachments = array();
					$headers = 'Content-Type: text/html;';
					wp_mail($form_data['emailTo'], $form_data['subject'], $form_data['message'], $headers, $attachments);
					$content = 'Test email was sent successfully!';
					$style = 'success';
					$notice['style'] = $style;
					$notice['content'] = $content;
					break;
				case 'smtp':
					$style = 'danger';
					$content = 'Failed to send the test email.';
					$mail = $this->wpoven_smtp_check_connection();
					if ($mail) {
						$responce = $this->send_mail($mail, $form_data);
						if ($responce) {
							$style = 'success';
							$content = 'Test email was sent successfully!';
						}
					}
					$notice['style'] = $style;
					$notice['content'] = $content;
					break;
				default:
					break;
			}
		}
		$fields[] = $notice;
		$email_to = array(
			'id'      => 'email_to',
			'type'    => 'text',
			'title'   => 'To',
			'placeholder'  => 'example@gmail.com',
			'desc'  => 'Email address of the recipient.',
		);

		$text_format = array(
			'id'    => 'text_format',
			'type'  => 'switcher',
			'title' => 'HTML',
			'default' => true,
			'desc'  => 'Enable email format: HTML or plain text.',
		);

		$sendMail = array(
			'id'         => 'send-smtp-mail-test',
			'type'       => 'button_set',
			'title'      => '&nbsp;',
			'options'    => array(
				'enabled'  => 'Send',
			),
			//'default'    => 'enabled'
		);

		$fields[] = $email_to;
		$fields[] = $text_format;
		$fields[] = $sendMail;

		$result = array(
			'title'     => 'Test Email',
			'icon'      => 'fa fa-gear',
			'fields'    => $fields
		);
		return $result;
	}

	/**mail
	 */
	function setup_gui()
	{
		$options = get_option(WPOVEN_SMTP_SURESEND_SLUG);
		CSF::createOptions(WPOVEN_SMTP_SURESEND_SLUG, array(
			'menu_title' => WPOVEN_SMTP_SURESEND,
			'menu_slug'  => WPOVEN_SMTP_SURESEND_SLUG,
			'framework_title' => WPOVEN_SMTP_SURESEND,
			'footer_credit' => ' ',
			'footer_text' => 'WPOven SMTP Suresend',
			'show_bar_menu' => true,
			'show_sub_menu' => true,
			'menu_hidden' => true,
			'show_reset_section' => false,
			'show_reset_all' => false,

		));

		$debug = array('type' => 'content', 'content' => print_r($options, true));
		CSF::createCustomizeOptions(WPOVEN_SMTP_SURESEND_SLUG, array(
			'database'        => 'option',
			'transport'       => 'refresh',
			'capability'      => 'manage_options',
			'save_defaults'   => true,
			'enqueue_webfont' => true,
			'async_webfont'   => false,
			'output_css'      => true,
		));
		CSF::createSection(WPOVEN_SMTP_SURESEND_SLUG, array(
			'fields' => array(
				array(
					'id'            => 'wpsmtp_settings',
					'type'          => 'tabbed',
					'tabs'          => array(
						$this->wpoven_smtp_suresend_general_settings($options),
						$this->wpoven_smtp_suresend_smtp_test_settings($options),
					),
				),
			)
		));
	}

	/**
	 * Create SMTP logs pages.
	 */
	function smtp_logs()
	{
		echo '<div class="wrap"><h1>WPOven SMTP Logs</h1>';
		echo '<form method="post">';

		$table = new WPoven_List_Table();
		$table->prepare_items();
		$table->search_box('search', 'search_id');
		$table->display();

		echo '</div></form>';
	}

	/**
	 * Hook to add the admin menu.
	 */
	public function admin_main(Wpoven_Smtp_Suresend $wpoven_smtp_suresend)
	{
		$this->_wpoven_smtp_suresend = $wpoven_smtp_suresend;
		add_action('admin_menu', array($this, 'wpoven_smtp_suresend_menu'));
		$this->setup_gui();
	}
}
